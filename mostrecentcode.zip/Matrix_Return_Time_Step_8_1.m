function [B_1,B_2,diag_1,diag_2] = Matrix_Return_Time_Step_8_1(k,n,h,rho,rho_max,dt,dx)
%This will update the state vector (density) at every timestep using an
%Euler method 
%additional function output is the covariance matrix nu 

F = zeros(n,1);
diag_1 = ones(n,1);
diag_2 = ones(n-1,1); 
S = @(rho) (1 -rho/rho_max)/(1 + 200*(rho/rho_max)^4);
for i = 1:n-1
  p = (1/2)*(rho(i,k) + rho(i+1,k));
  a = S(p);%making lower diagonal5
  diag_2(i,1) = a;  
end

diag_1(1:(n-1),1) = diag_2; 

F(n,1) = rho(n,k)*S((1/2)*rho(n,k)); 
for i = 1:n-1
p = (1/2)*(rho(i,k) + rho(i+1,k));  
F(i,1) = S(p); %column vector
end 

diag_1(n,1) = S((1/2)*(rho(i,k)));
G = diag(diag_1,0); 
G = G + diag(diag_2,-1);  
B_1 = (dt/dx)*G;
B_2 = (h/dx)*G; 

end 