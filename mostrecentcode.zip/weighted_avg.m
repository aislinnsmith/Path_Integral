
function [Noise_Real] = weighted_avg(Random_Path_Noise, Random_Path_Cost)
   Noise_Real = Random_Path_Cost.*Random_Path_Noise;     
end