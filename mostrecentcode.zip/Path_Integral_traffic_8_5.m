
close; clc; clear; 
%SDE := dp = (v_o/dx)F(dt) + (dt/dx)*M*u + (h/dx)MdW;
%p is a nx1 matrix, M is an nxn matrix, dE is an nx1 matrix and nu 
%(h/dx)M is an nxn matrix

%!!!!!!!!! need to convert everything to column vectors !!!!!!!!!!!
n = 4;
h = 0.01;
dt = 15/3600;
dx = 0.005;
lambda = (h/dt)^2; %variance may change, but lambda is constant.
rho_max = 5;
V_o = 5; 
S = @(rho)(1 - (rho/rho_max))/(1 + 200*(rho/rho_max)^4);
% The initial time step in the simulation
T0 = 0;
% The final time step in the simulation [units: hrs]
Tf = 1;
% Create a vector of times to run the simulation over using previously set time step size
Tspan = T0:dt:Tf;

% Determine the total number of time steps the simulation is evaluated at.
Tsize = length(Tspan)-1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Important: for each time step, we are completely redoing the sampling because we need to sample ateach initial time, which
%will change based on what control imput we use in the previous time step
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Construct the noise terms to be used for the Monte Carlo Simulation

% We use Wiener Process noise (form of white noise?) as it has the specific
% form necessary for the path integr%al control discussed in [Kappen, "Path
% Integrals and Symmetry Breaking for Optimal Control Theory", 2008. Page 3,7]

% The probability of the Wiener is Gaussian with mean zero and variance

rho_t_c = 0.05*ones(n,Tsize);
u_t_c = zeros(n,Tsize);
running_cost = 0;

for k = 1:Tsize
%need to return the matrices B_1 and B_2
b = zeros(n,1);
trace = zeros(n,1); 
[B_1,B_2,diag_1,diag_2] = Matrix_Return_Time_Step_8_1(k,n,h,rho_t_c,rho_max,dt,dx);

trace(1,1) = func_Construct_dH_8_5(n,rho_max,rho_t_c(:,k),1,B_1*B_1');
trace(2,1) = func_Construct_dH_8_5(n,rho_max,rho_t_c(:,k),2,B_1*B_1');
trace(3,1) = func_Construct_dH_8_5(n,rho_max,rho_t_c(:,k),3,B_1*B_1'); 
trace(4,1) = func_Construct_dH_8_5(n,rho_max,rho_t_c(:,k),4,B_1*B_1'); 

trace = (0.5)*trace;

H = B_1*B_1';

b = lambda*H*trace;

M = inv(B_1*B_1'); 

m = 10000; %initial condition of state vect

Random_Path_Cost = zeros(1,m,'gpuArray');% mx1 GPU array that stores the terminal cost of each sample path starting at initial state

Init_Random_Path_Noise = zeros(n,m,'gpuArray'); %mx1 GPU array that stores the initial noise of each sample path starting at initial state

rho_o = rho_t_c(:,k);

parfor j = 1:m
    
    Sample_Path = zeros(n,Tsize-(k-1)); %each row is a 1 by 4
    Sample_Noise = zeros(n,Tsize-(k-1)); 
    Sample_Path(:,1) = rho_o;   
    Sample_Running_Cost = 0;
    a = 0; 
 for i = 1:Tsize-(k-1)    %(Tsize-(k-1)) %this loop will simulate every sample path time step will shorten the trajectory path
        
    [Sample_Path(:,i+1),Sample_Noise(:,i)] = SDE_dynamics_nu_8_1(1,n,h,V_o,Sample_Path(:,i),rho_max,zeros(n,1),randn(n,1)*sqrt(dt),dt,dx);
    Sample_Running_Cost = terminal_cost_phi(dx,n,Sample_Path(:,i),V_o,rho_max) + Sample_Running_Cost;
    if Sample_Path(:,i+1) > 5
        a = 1; 
        break
    end
 end
    if a == 0
    phi_Tf = terminal_cost_phi(dx,n,Sample_Path(:,Tsize-(k-1)),V_o,rho_max);
    Random_Path_Cost(1,j) = exp(-phi_Tf/lambda);%Gives us terminal cost for the mth path (i.e. w_m) 
    Init_Random_Path_Noise(:,j) = Sample_Noise(:,1);%load the initial noise into the array that collects noise for all m sample paths 
    
    else 
    Random_Path_Cost(1,j) = 0; 
    Init_Random_Path_Noise(:,j) = zeros(n,1); 
    end 
end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Now that we have run the simulation for all m samples, we need to collect
%that data to for a solution for a single step (the result of this step
%will become the initial state for the next round of "m" Monte Carlo
%simulations)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P = m;
for i = 1:m 
    if Init_Random_Path_Noise(1,i) == 0
        P = P - 1; 
    end
end

psi_real = (1/P)*sum(Random_Path_Cost); %This will be a scalar
psi_real = gather(psi_real); 
 


[Noise_Real] = arrayfun(@weighted_avg,Init_Random_Path_Noise,Random_Path_Cost); %w_i*dE 

Noise_Real = gather(Noise_Real);
Noise_Real_sum = (1/P)*sum(Noise_Real,2); 
%this will give us a vector with "m" spots st.
%the ith element is equal to w(t_o)_i*dE(t_o)_i (initial weighted noise)
%eqn 30 
  
%First we need to compute weights for the trajectories from the noise 
u_t_c(:,k) = (B_1)\((Noise_Real_sum - b)/(psi_real*dt)); %(B_1^T(B_2B_2^T)^(-1)sum(w_i*dE_i) eqn 30 
u_t_c(:,k)

dE = Noise_Real_sum; 

[rho_t_c(:,k+1),A] = SDE_dynamics_nu_8_1(1,n,h,V_o,rho_t_c(:,k),rho_max,u_t_c(:,k),dE,dt,dx);  %using discretized matrices 

running_cost = running_cost + (1/2)*u_t_c(:,k)'*u_t_c(:,k) + terminal_cost_phi(dx,n,rho_t_c(:,k),V_o,rho_max); 

end

running_cost

figure(1)
    
t = 1:Tsize;
plot(t,rho_t_c(t,1),'-o');
title('rho_t_c(t)')