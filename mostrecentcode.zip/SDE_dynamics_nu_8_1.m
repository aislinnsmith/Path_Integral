function [rho_new,sample_noise] = SDE_dynamics_nu_8_1(k,n,h,V_o,rho,rho_max,u_t,dW,dt,dx)
%This will update the state vector (density) at every timestep using an
%Euler method 
%additional function output is the covariance matrix nu 


F = zeros(n,1);
diag_1 = ones(n,1);
diag_2 = ones(n-1,1); 
S = @(rho) (1 -rho/rho_max)/(1 + 200*(rho/rho_max)^4);
for i = 1:n-1
  p = (1/2)*(rho(i,k) + rho(i+1,k));
  a = rho(i,k)*S(p);%making lower diagonal
  diag_2(i,1) = a;  
end


diag_1(1:(n-1),1) = -diag_2; 

F(n,1) = rho(n,k)*S((1/2)*rho(n,k)); 
for i = 1:n-1 
p = (1/2)*(rho(i,k) + rho(i+1,k));  
F(i,1) = S(p); %column vector
end 
diag_1(n,1) = rho(n,k)*S((1/2)*(rho(n,k))); 
G = diag(diag_1,0); 
G = G + diag(diag_1(1:(n-1),1),-1);  
rho_new = rho + (V_o*dt/dx)*F + (dt/dx)*G*u_t +(h/dx)*G*dW; %(h/dX)G is equal to the square of the covariance matrix
sample_noise = (h/dx)*G*dW;
end 