
%will need to use the symbolic math package here.
%We are symbolically constructing the matrix H so that we can take it's
%derivative and the plug in the current values of the state vector into it.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%This will be the symbolic derivative of matrix of B*B^T = D with respect to rho_i, we will be doing this element wise (needed for compute b) 

%we will be taking a derivative with respect to p_k (may need to change number of variables later
function [trace_1] = func_Construct_dH_8_5(n,rho_max,rho,k,H)
 
C = strcat('p_',num2str(k)); %We wish to differentiate with respect to this variable
c = evalin(symengine, C);
S = @(rho) (1 -rho/rho_max)/(1 + 200*(rho/rho_max)^4);
S_squared = @(rho) ((1 -rho/rho_max)/(1 + 200*(rho/rho_max)^4)^2);
dH_1 = zeros(n,n); 
%Let's build matrix D symbolically (the key fact is the for B*B^T = D, dij
%= bi dot bj (where b_i is the ith row) 

syms('p_1','p_2','p_3', 'p_4')

%lets calculate H^{-1}*d_1H
for j = 1:n 
    for i = 1:n 
    
       if j == i 
            
           A = strcat('p_',num2str(i));
           B = strcat('p_',num2str(i-1));
           a = evalin(symengine, A);
           b = evalin(symengine, B); %this should return symbol 'p_{j-1}' %for now, we are using equation rho*(S(rho)) %temporary symbolic handle 
           dh_1 = diff((a^2*S_squared(a) + b^2*S_squared(b)),c); 
           dh1 = matlabFunction(dh_1);
           if dh_1 ~= 0
               dH_1(i,j) = dh1(rho(k,1));
               
           end
           
       end
      
       if abs(j - 1) == 1
           A = strcat('p_',num2str(i));
           B = strcat('p_',num2str(j));
           a = evalin(symengine, A);
           b = evalin(symengine, B); 
           
           if j > i
                dh_2 = diff((a^2*S_squared(a)),c); 
                dh2 = matlabFunction(dh_2);
                    if dh_2 ~= 0
                        dH_1(i,j) = dh2(rho(k,1));
                    end
           end
           
           if i < j 
               dh_3 = diff((b^2*S_squared(b)),c); 
               dh3 = matlabFunction(dh_3);
                    if dh_3 ~= 0
                        dH_1(i,j) = dh3(rho(k,1));
                    end
           end 
      end 
    
    end 
end 

trace_1  = trace(H\dH_1); 

end
