
%function LQR_Toy_Problem_with_Noise
%Here I am comparing the optimal trajectories given by the backwards
%Ricatti LQR formulation v.s. the path integral formulation on the inverted
%pendulum problem
close; clc; clear; 
%SDE := dx = Axdt+B(udt+dw); s.t. dE = BdW ----> E[dx^2] = E[BdW] = B*nu*B^T (affine
%transformation of random variable (dE is a Wiener process) 
%Cost functional: phi(T) + int(u'*R*u + x'*B*x)dt 
%reference is LQR matlab site: https://ctms.engin.umich.edu/CTMS/index.php?example=InvertedPendulum&section=ControlStateSpace
%in this model u is a 4x1, B is a 4x4, A is a 4x4, and dW is a 4x1
n = 4;
lambda = 2;
dt = 0.01;
A = [0,1,0,0;0,0,-1,0;0,0,0,1;0,0,9,0]; 
B = eye(n,n);%B_d = int_{0,dt}exp(A*dt)
R = 2*eye(n,n); 
Q = diag([1,1,10,10]); 
nu = B*B';%This is the discretization of the covariance matrix 
P = inv(B*B'); 
sigma = B;

% The initial time step in the simulation
T0 = 0;
% The final time step in the simulation [units: hrs]
Tf = 0.5;
% Create a vector of times to run the simulation over using previously set time step size
Tspan = T0:dt:Tf;

% Determine the total number of time steps the simulation is evaluated at.
Tsize = length(Tspan)-1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Important: for each time step, we are completely redoing the sampling because we need to sample ateach initial time, which
%will change based on what control imput we use in the previous time step
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Construct the noise terms to be used for the Monte Carlo Simulation

% We use Wiener Process noise (form of white noise?) as it has the specific
% form necessary for the path integr%al control discussed in [Kappen, "Path
% Integrals and Symmetry Breaking for Optimal Control Theory", 2008. Page 3,7]

% The probability of the Wiener is Gaussian with mean zero and variance

x_t_c = 0.5*ones(n,Tsize); %n dimensional column vectors

u_t_c = zeros(n,Tsize); %scalar
running_cost = 0; 
rng default 

for k = 1:Tsize
m = 100000; %initial condition of state vect

Random_Path_Cost = zeros(1,m,'gpuArray');% mx1 GPU array that stores the terminal cost of each sample path starting at initial state
Random_Path_Noise = zeros(n,m,'gpuArray'); %mx1 GPU array that stores the initial noise of each sample path starting at initial state
x_o = x_t_c(:,k); %state at current time step is assigned to be initial state for sample paths 
parfor j = 1:m
    
    Sample_Path = zeros(n,Tsize-(k-1)); %each column is 4 dim
    Sample_Path(:,1) = x_o;   
    Sample_Cost = 0;
    dE = zeros(n,Tsize-(k-1)); %each samples is 4x1
    for i = 1:(Tsize-(k-1)) %every time step will shorten the trajectory path
        dE(:,i) = sqrt(dt)*sigma*randn(4,1);% 4 x 1 noise with adjusted variance 
        Sample_Path(:,i+1) = Sample_Path(:,i) + A*Sample_Path(:,i)*dt + dE(:,i); 
        Sample_Cost = Sample_Cost + (Sample_Path(:,i)'*Q*Sample_Path(:,i)); 
    end
    phi_Tf = (Sample_Path(:,Tsize-(k-1))'*Q* Sample_Path(:,Tsize-(k-1))); 
    Random_Path_Cost(:,j) = (1/m)*exp(-phi_Tf/lambda);
    %Gives us terminal cost for the mth path
    Random_Path_Noise(:,j) = dE(:,1);   
 end %Gives us noise at first step for mth path
  
%Goal is to apply function m times, and in each iteration simulate the
%entire sample path from intial state, return the final cost and initial noise 
psi_real = sum(Random_Path_Cost);
psi_real = gather(psi_real); 
 

[Noise_Real] = arrayfun(@weighted_avg,Random_Path_Noise,Random_Path_Cost);
 

dE_real = sum(Noise_Real,2); %weighted average of the rows
dE_real = gather(dE_real);

%First we need to compute weights for the trajectories from the noise 
u_t_c(:,k) = (B\(dE_real))/((psi_real*dt)); 
u_t_c(:,k)
%Currently, the issue is that the control term is not doing much to deviate
%from uncontrolled path 
%By HJB: u = (-R^{-1}*B^T*d_xJ) = -R^{-1}*B^T*(-P)) (-P is defined in eqn
%20) 
%eqn 29 Kappen: sum(w_i*dE_i)/(psi*dt)
%in discretization, we assume the control is constant for each time step
%interval 

x_t_c(:,k+1) = x_t_c(:,k) + A*x_t_c(:,k)+ B*u_t_c(:,k) + dE_real; %using discretized matrices 

running_cost = x_t_c(:,k)'*Q*x_t_c(:,k) + (1/2)*(u_t_c(:,k)'*R*u_t_c(:,k)) + running_cost;

end
running_cost

figure(1)
a = num2str(running_cost);
b = strcat(x_t_c(1),' ',a);
t = 1:Tsize;
plot(t,x_t_c(1,t),'-o');
title(b)
